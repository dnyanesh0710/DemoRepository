import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from 'src/model/User';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient:HttpClient) {
  }

  checkUser(user:User){
    return this.httpClient.post<string>('http://localhost:9051/api/user/authenticate',user);
  }
}
