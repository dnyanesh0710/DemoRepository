import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(private router:Router) { }

  canActivate():boolean {
    console.log("IN can activate")
    //to do if user logged in if yes allow access (return true) else return false
    //this result var should be fetch in if block and accordingly navigation of application can be decided.
    if(false){
      this.router.navigate(['login'])
      return false
    }
    return true
  }
}
