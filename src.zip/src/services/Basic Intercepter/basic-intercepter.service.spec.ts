import { TestBed } from '@angular/core/testing';

import { BasicIntercepterService } from './basic-intercepter.service';

describe('BasicIntercepterService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BasicIntercepterService = TestBed.get(BasicIntercepterService);
    expect(service).toBeTruthy();
  });
});
