import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Message } from 'src/model/Message';

@Injectable({
  providedIn: 'root'
})
export class MessageDataService {

  //messages:string[]=[];
  private arr:Message[]=[];

  constructor(private http:HttpClient) {
    
  }

  getMessages(){
    //let h=new HttpHeaders().append("Authorization","Basic "+btoa("zensar:zensar"))
    return this.http.get<Message[]>(environment.url+'/api/messages'/*,{headers:h}*/)
  }

  deleteMessage(id:number){
    //let h=new HttpHeaders().append("Authorization","Basic "+btoa("zensar:zensar"))
    return this.http.delete(environment.url+'/api/delete/'+id/*,{headers:h}*/)
  }

  updateMessage(msg:Message){
    //let h=new HttpHeaders().append("Authorization","Basic "+btoa("zensar:zensar"))
    return this.http.put<Message>(environment.url+'/api/update',msg)
  }


  addMessage(msg:Message){
    //let h=new HttpHeaders().append("Authorization","Basic "+btoa("zensar:zensar"))
    return this.http.post<Message>(environment.url+'/api/addMessage',msg)
  }
  getMessagesWithObservable():Observable<Message[]>{
    return of(this.arr)
  }
}
