import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { MessageComponent } from './message/message.component';
import { FormsModule } from '@angular/forms';
import { MessageUpdateComponent } from './message-update/message-update.component';
import { MenuComponent } from './menu/menu.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RouterModule } from '@angular/router';
import { Routes } from '@angular/router';
import { NotFoundComponent } from './not-found/not-found.component';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http'
import { BasicIntercepterService } from 'src/services/Basic Intercepter/basic-intercepter.service';
import { AuthGuardService } from 'src/services/AuthService/auth-guard.service';

//declare an array.
const routes:Routes=[
  {path:"login",component:LoginComponent},
  {path:"message",component:MessageComponent,canActivate:[AuthGuardService]},
  {path:"",component:HomeComponent},
  {path:"home",redirectTo:""},
  {path:"**",component:NotFoundComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    MessageComponent,
    MessageUpdateComponent,
    MenuComponent,
    FooterComponent,
    LoginComponent,
    HomeComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule
  ],
  providers: [/*{provide:HTTP_INTERCEPTORS,useClass:BasicIntercepterService,multi:true}*/],
  bootstrap: [AppComponent]
})
export class AppModule { }
