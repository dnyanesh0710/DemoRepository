import { Component, OnInit } from '@angular/core';
import { Message } from 'src/model/Message';
import { MessageDataService } from '../message-data.service';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit {
  messages: string[] = [];   //array of strings
  message: Message = new Message()
  updateBtnClick: boolean = false;
  arr: Message[] = [];
  tempArr: Message;
  deleteMsgOutput: string
  addDiv:boolean=true;
  newMessage:Message=new Message();

  constructor(private service: MessageDataService) {    //dependency injection done by passing arg to constrcutor
    this.loadMessages()
  }

  loadMessages() {
      this.service.getMessages().subscribe(success => this.arr = success, error=>{
      //this.deleteMsgOutput="Server not reachable !!"
      this.deleteMsgOutput=error.message+error.status
      this.addDiv=false
    })
  }

  //this method is called from child component in response to event binding
  doUpdate(msgToBeUpdated: Message) {
    for (let m in this.arr) {
      if (msgToBeUpdated.id == this.arr[m].id) {
        this.arr[m] = new Message(msgToBeUpdated.id, msgToBeUpdated.name);
        this.updateBtnClick = false;
      }
    }
  }

  getMessages() {
    return this.messages;
  }

  deleteEntry(id: number): void {
    let res = confirm("Are you sure?")
    if (res) {
      console.log("Deleting ID: " + id)
      this.service.deleteMessage(id).subscribe(success => {
        console.log(success)
        if (!success) {
          this.deleteMsgOutput = "Something went wrong. Please try again !!"
        }
        else {
          this.loadMessages()
          this.deleteMsgOutput = "Successfully deleted"
        }
      })
    }
  }

  addNewMessage() {
    this.service.addMessage(this.newMessage).subscribe(success=>{
      console.log(success)
      this.loadMessages()
    })
  }

  updateEntry(idParam: number): void {
    console.log("Updating ID: " + idParam);
    this.updateBtnClick = true;
    for (let f of this.arr) {
      if (f.id == idParam) {
        //this.message=f;
        this.message = new Message(f.id, f.name);
        break;
      }
    }
  }
  ngOnInit() {
  }

}
