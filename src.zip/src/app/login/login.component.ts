import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/model/User';
import { UserService } from 'src/services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user:User=new User();
  

  constructor(private userService:UserService,private router:Router) {

  }

  loginUser(){

    this.userService.checkUser(this.user).subscribe(token=>console.log(token));
      //this.router.navigate(["message"])
  }

  ngOnInit() {
  }

}
